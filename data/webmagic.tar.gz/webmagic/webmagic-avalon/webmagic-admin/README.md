WebMagic-Admin
=====
Admin is the control web of workers.