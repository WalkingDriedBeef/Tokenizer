WebMagic-Avalon
========
> Spiders Manage Web

see [#issue43](https://github.com/code4craft/webmagic/issues/43)