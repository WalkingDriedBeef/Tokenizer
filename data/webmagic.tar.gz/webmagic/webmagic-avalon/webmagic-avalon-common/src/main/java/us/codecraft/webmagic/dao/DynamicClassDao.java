package us.codecraft.webmagic.dao;

import us.codecraft.webmagic.model.DynamicClass;

/**
 * @author code4crafter@gmail.com
 */
public interface DynamicClassDao {

    public int add(DynamicClass dynamicClass);
}
